﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MBT
{
    public abstract class BlackboardVariable : MonoBehaviour
    {
        public string key;
    }
}
